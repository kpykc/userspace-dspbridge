TITLE
-----
ACPY2 module for C6211/6711 EDMA devices (compatible with C64x)

DESCRIPTION
-----------
This module implements the ACPY2 library for XDAIS algorithms, as per the 
XDAIS specifications.

FILES
-----
Each ACPY2 function is placed in a separate file to avoid dead code, unless 
two or more functions are always dependent; in that case, they are placed
together in a single source file.

- acpy2_6x1x.pjt: project files for building the library 
- idma2_priv.h: private implementation of an IDMA2_Obj structure (logical handle)
- _acpy2.h:  private header file for this ACPY2 implementation
- acpy2_6x1x.c: definition of the module configuration structure
- acpy2_6x1x_init.c: ACPY2_6x1x_init function
- acpy2_6x1x_exit.c: ACPY2_6x1x_exit function
- acpy2_start.s62: optimized ACPY2_start function
- acpy2_start.c: c-model of ACPY2_start function (same functionality but not 
  optimized)
- acpy2_startaligned.s62: optimized ACPY2_startAligned function
- acpy2_startaligned.c: c-model of ACPY2_startAligned function (same functionality 
  but not optimized)
- acpy2_wait.c: ACPY2_wait function
- acpy2_setsrcframeidx.c: ACPY2_setSrcFrameIndex function
- acpy2_setdstframeidx.c: ACPY2_setDstFrameIndex function
- acpy2_setnumframes.c: ACPY2_setNumFrames function
- acpy2_initchan.c: ACPY2_initChannel function
- acpy2_init.c: ACPY2_init function
- acpy2_getchanobjsize.c: ACPY2_getChanObjSize function
- acpy2_exit.c: ACPY2_exit function
- acpy2_configure.c: ACPY2_configure function
- acpy2_complete.c: ACPY2_complete function
- acpy2_6x1x.h: public header file for the ACPY2_6x1x module
- readme.txt: this file

NOTE
----
Files in the library are compiled with optimization switches turned on. If you 
want to debug this module, it is advised that you rebuild the library with 
optimization turned off.

Q&A
---
Q1: What is the use of the ACPY2_6x1x module?

---
Q1: What is the use of the ACPY2_6x1x module?
A1: It provides an example ACPY2 library implementation for XDAIS algorithms 
that implements the IDMA interface in the application.  The code is optimized 
for the C6211/6711 EDMA devices; however, it is compatible with the C64x devices
and can be used at the cost of some performance penalty as it does not fully utilize
the new features available on C64x EDMA.  Note that it does not support any of the 
extended features available only on the C64x (e.g. transfer completion codes (TCC) 
greater than 16)   
 