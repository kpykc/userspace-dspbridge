/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_initchan.c ========
 */
#pragma CODE_SECTION(ACPY2_initChannel, ".text:ACPY2_initChannel")

#include <std.h>

#include <csl_edma.h>

#include <_acpy2.h>
#include <idma2_priv.h>

#ifdef _64_
#define NUM_QUEUES 4
#else
#define NUM_QUEUES 2
#endif

/* 
 * External reference set up by user to inform the library on which
 *     particular hardware EDMA transfer request queues to use.
 */
extern Uns ACPY2_QUEUE_MAP[NUM_QUEUES];

/*
 *  ======== ACPY2_initChannel ======== 
 *  Initialize the IDMA2 channel object passed in.  Set the priority level
 *  based on the queue id.
 *
 */
Void ACPY2_initChannel(IDMA2_Handle handle, Int queueId)
{    
    /* 
     * NOTE: qid is an arbitrary number that has to be mapped to physical
     * hardware queues on the C6x EDMA device.  The scheme chosen here
     * is to map queueId % NUM_QUEUES to a user specified priority level,
     * defined in ACPY2_QUEUE_MAP.
     */
    (handle->config).opt = EDMA_FMK(OPT,PRI,ACPY2_QUEUE_MAP[queueId % NUM_QUEUES]);
}



