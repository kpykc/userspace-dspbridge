/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_setsrcframeidx.c ========
 */
#pragma CODE_SECTION(ACPY2_setSrcFrameIndex, ".text:ACPY2_setSrcFrameIndex")

#include <std.h>

#include <csl_edma.h>

#include <idma2_priv.h>

/*
 *  ======== ACPY2_setSrcFrameIndex ======== 
 *  Rapidly configure the source Frame index parameter of an IDMA2 channel
 *  Note that both source and destination indexes are set simultaneously 
 *  on the C6x1x with this API.
 */
Void ACPY2_setSrcFrameIndex(IDMA2_Handle handle, Int frameIndex)
{
    handle->params.srcFrameIndex = frameIndex;
    
    /*
     * For 2D to 2D transfers, src and dst indices must be set to same
     * value.
     */
    if (handle->params.xType == IDMA2_2D2D) {
        handle->params.dstFrameIndex = frameIndex;
    }   
    
    /*
     * The idx register value is recomputed
     */
    handle->config.idx &= 0x0000FFFF;  //clear the frame index field
    handle->config.idx |= 
        EDMA_FMK(IDX,FRMIDX,(handle->params.srcFrameIndex)); 
}


