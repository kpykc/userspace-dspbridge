/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/* 
 *  ======== dman.h ======== 
 *  Application interface to dma manager (dman.c). Provides routines for
 *  granting DMA resources to algorithms. 
 */

#ifndef DMAN_
#define DMAN_

#include <ialg.h>
#include <idma2.h>

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

/* 
 *  ======== DMAN_addAlg ======== 
 *  Grant logical channel resources to an algorithm instance
 */
extern Bool DMAN_addAlg(IALG_Handle algHandle, IDMA2_Fxns *dmaFxns);

/*
 *  ======== DMAN_exit ======== 
 *  Finalization method of the DMAN module
 */
extern Void DMAN_exit(Void);

/*
 *  ======== DMAN_init ======== 
 *  Initialize the DMAN module
 */
extern Void DMAN_init(Void);

/* 
 *  ======== DMAN_removeAlg ======== 
 *  Remove logical channel resources from an algorithm instance
 */
extern Bool DMAN_removeAlg(IALG_Handle algHandle, IDMA2_Fxns *dmaFxns);

/*
 *  ======== DMAN_setup ======== 
 *  Setup the DMAN module.  Specifies the size of the IDMA2_Obj
 */
extern Void DMAN_setup(Int heapId); 

#ifdef __cplusplus
}
#endif /*__cplusplus*/

#endif /*DMAN_*/



