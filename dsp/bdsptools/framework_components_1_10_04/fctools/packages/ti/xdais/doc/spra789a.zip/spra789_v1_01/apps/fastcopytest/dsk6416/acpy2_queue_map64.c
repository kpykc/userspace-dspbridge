/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_queue_map64.c ========
 */
#include <std.h>

#include <csl_edma.h>

/*
 * This array serves as a configuration parameter and is used inside 
 *     the ACPY2 library to determine which hardware EDMA transfer
 *     request queues to use.
 */
Uns ACPY2_QUEUE_MAP[] = {
        EDMA_OPT_PRI_LOW,
        EDMA_OPT_PRI_LOW,
        EDMA_OPT_PRI_LOW,
        EDMA_OPT_PRI_LOW,
};        


