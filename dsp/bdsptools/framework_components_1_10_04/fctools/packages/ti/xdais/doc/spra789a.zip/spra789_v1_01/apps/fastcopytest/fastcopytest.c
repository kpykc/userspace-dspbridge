/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== fastcopytest.c ========
 *  Test application for FCPY algorithm.  Copies a 2D block from one 
 *  location to another in memory, one quadrant at a time.
 */
// External data sections
#pragma DATA_SECTION(input,".image:ext_sect1")
#pragma DATA_SECTION(output,".image:ext_sect2")
#pragma DATA_ALIGN(input,128)   // aligned on cache boundary
#pragma DATA_ALIGN(output,128)  // aligned on cache boundary

#include <std.h>
#include <sys.h>
#include <log.h>

#include <csl_cache.h>

#include <alg.h>
#include <ialg.h>
#include <ifcpy.h>
#include <dman.h>
#include <acpy2_6x1x.h>
#include <fcpy.h>

#define SLINELEN  32    /* in bytes */
#define SNUMLINES 32    /* in bytes */
#define SSTRIDE   32    /* in bytes */
#define DLINELEN  32    /* in bytes */
#define DNUMLINES 32    /* in bytes */
#define DSTRIDE   32    /* in bytes */

#define INPUTSIZE   1024        /* in words */
#define OUTPUTSIZE  INPUTSIZE   /* in words */

//2D 64x64 Input and output data buffers
int input[INPUTSIZE];
int output[OUTPUTSIZE];

extern far Int INTERNALHEAP;
extern far Int EXTERNALHEAP;
extern LOG_Obj LOG_myLog;

extern far IFCPY_Fxns FCPY_IFCPY;      /* FCPY algorithm's v-table */
extern far IDMA2_Fxns FCPY_IDMA2;        /* FCPY algorithm's IDMA2 v-table */

Int main(Void)
{
    Int i;
    FCPY_Params fcpyParams;
    FCPY_Handle alg;
    Bool errorFlag = FALSE;
    IFCPY_Fxns * fxns = (IFCPY_Fxns *)&FCPY_IFCPY;      

    FCPY_init();        //Initialize the framework
    
    // Set up param structure
    fcpyParams = FCPY_PARAMS;
    fcpyParams.srcLineLen = SLINELEN;
    fcpyParams.srcNumLines = SNUMLINES;
    fcpyParams.srcStride = SSTRIDE;    
    fcpyParams.dstLineLen = DLINELEN;
    fcpyParams.dstNumLines = DNUMLINES;
    fcpyParams.dstStride = DSTRIDE;
    
    // Use the ALG interface to create a new algorithm instance
    if ((alg = FCPY_create(fxns, &fcpyParams)) == NULL) {
        SYS_abort("Could not create algorithm instance");
    }
    
    //
    // Initialize DMA manager and ACPY2 library for XDAIS algorithms
    // and grant DMA resources
    // 
    ACPY2_6X1X_init();
    DMAN_init();
    DMAN_setup(INTERNALHEAP);
    if (DMAN_addAlg((IALG_Handle)alg, &FCPY_IDMA2) == FALSE) {
        SYS_abort("Problem adding algorithm's dma resources");
    }    

    CACHE_clean(CACHE_L2ALL, NULL, NULL); 
      
    // Initialize data arrays
    for (i = 0; i < INPUTSIZE; i++) 
    {
        input[i] = i; 
        output[i] = 0xDEADBEEF;
    }     

    CACHE_clean(CACHE_L2ALL, NULL, NULL); 
  
    //
    // Copy input to the output one quadrant at a time
    //
    // Quadrant 2
    FCPY_apply((FCPY_Handle)alg, input, output);  
    // Quadrant 1
    FCPY_apply((FCPY_Handle)alg, input + (SSTRIDE/4), output + (DSTRIDE/4));
    // Quadrant 3
    FCPY_apply((FCPY_Handle)alg, input + (INPUTSIZE/2), 
                   output + (OUTPUTSIZE/2));
    // Quadrant 4
    FCPY_apply((FCPY_Handle)alg, input + (INPUTSIZE/2) + (SSTRIDE/4), 
                   output + (OUTPUTSIZE/2) + (DSTRIDE/4));
    
    // Verify output
    for (i = 0; i < OUTPUTSIZE; i++)
    {
        if (output[i] != i) {
            LOG_printf(&LOG_myLog, " %d th element in output should not be %d.\n"
                        , i, output[i]);
            errorFlag = TRUE;
        }
    } 
         
    if (errorFlag == FALSE) {
        LOG_printf(&LOG_myLog, "Pass \n");
    }
     
    //
    // Withdraw DMA resources from algorithm and deinitialize the DMA 
    // manager and ACPY2 library   
    //                             
    if (DMAN_removeAlg((IALG_Handle)alg, &FCPY_IDMA2) == FALSE) {
        SYS_abort("Problem removing algorithm's dma resources");
    }       

    // delete the algorithm instance 
    ALG_delete((IALG_Handle)alg);

    // module finalization
    DMAN_exit();
    ACPY2_6X1X_exit();     
    FCPY_exit();    //Deinitialize the framework
    
    return (0);
}

