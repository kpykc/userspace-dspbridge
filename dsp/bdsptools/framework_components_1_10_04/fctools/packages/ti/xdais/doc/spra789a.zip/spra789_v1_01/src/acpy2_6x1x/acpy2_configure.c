/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_configure.c ========
 */
/*
 * ======== ACPY2_configure ======== 
 * Configure a logical channel
 */
 
#pragma CODE_SECTION(ACPY2_configure, ".text:ACPY2_configure")

#include <std.h>
#include <sys.h>

#include <csl_edma.h>

#include <idma2_priv.h>

Void ACPY2_configure(IDMA2_Handle handle, IDMA2_Params *params)
{
    //Save priority level set
    Uns priField = EDMA_FGETA(&((handle->config).opt),OPT,PRI);
           
    handle->params = *params;

    /* 
     *  Default value for option register.  The assumption here for c64x
     *  devices is that the extra fields have default values of 0.
     */
    handle->config.opt = 
        EDMA_FMKS(OPT,PRI,OF(priField)) |
        EDMA_FMKS(OPT,ESIZE,OF(0)) |
        EDMA_FMKS(OPT,TCINT,YES) |
        EDMA_FMKS(OPT,TCC,OF(0)) |
        EDMA_FMKS(OPT,LINK,NO); 
           
    //Frame and element count set to 0 for 1D transfers
    handle->config.cnt = 0;  
            
    if (params->xType != IDMA2_1D1D) {  //For 2D transfers
    
        /*
         *  params->stride and params->numFrames are only initialized when it is 
         *  not a 1D transfer
         */ 
        handle->config.cnt = EDMA_FMK(CNT,FRMCNT,((params->numFrames) - 1));  
        
        //Check if element indexing is used        
        if ((params->srcElementIndex == 0) && 
            (params->dstElementIndex == 0)) {
            switch (params->xType) {
                case IDMA2_2D2D:
                    handle->config.opt |= 
                        EDMA_FMKS(OPT,FS,YES)   |            
                        EDMA_FMKS(OPT,SUM,INC) | 
                        EDMA_FMKS(OPT,DUM,INC) |
                        EDMA_FMKS(OPT,2DS,YES) | 
                        EDMA_FMKS(OPT,2DD,YES);
                    //Check for invalid src and dst frame index combinations
                    if (params->srcFrameIndex != params->dstFrameIndex) {
                        SYS_abort("Frame indices must be same in 2D2D transfers");
                    }
                    else {
                        handle->config.idx = EDMA_FMK(IDX,FRMIDX,
                            (params->dstFrameIndex));               
                    }
                    break;
                case IDMA2_1D2D:
                    handle->config.opt |= 
                        EDMA_FMKS(OPT,FS,YES)   |            
                        EDMA_FMKS(OPT,SUM,INC) | 
                        EDMA_FMKS(OPT,DUM,INC) |
                        EDMA_FMKS(OPT,2DS,NO) | 
                        EDMA_FMKS(OPT,2DD,YES);
                    handle->config.idx = EDMA_FMK(IDX,FRMIDX,
                        (params->dstFrameIndex));
                    break;
                case IDMA2_2D1D:
                    handle->config.opt |= 
                        EDMA_FMKS(OPT,FS,YES)   |            
                        EDMA_FMKS(OPT,SUM,INC) | 
                        EDMA_FMKS(OPT,DUM,INC) |
                        EDMA_FMKS(OPT,2DS,YES) |
                        EDMA_FMKS(OPT,2DD,NO);
                    handle->config.idx = EDMA_FMK(IDX,FRMIDX,
                        (params->srcFrameIndex));
                    break;
                default:
                    //Should never end up here!
                    SYS_abort("Invalid transfer type");
                    break;
            }
        }
        else { 
            SYS_abort("Element index has to be zero in 2D transfers on C6x1x");
        }
                                
    }
    else {   //For 1D transfers
        //Check if element indexing is used
        if ((params->srcElementIndex == 0) && 
            (params->dstElementIndex == 0)) {
            //Both src and dst have element indexing mode disabled
            handle->config.idx = 0;  
            handle->config.opt |= 
                 EDMA_FMKS(OPT,FS,YES)   |            
                 EDMA_FMKS(OPT,SUM,INC) | 
                 EDMA_FMKS(OPT,DUM,INC) |
                 EDMA_FMKS(OPT,2DS,NO) |
                 EDMA_FMKS(OPT,2DD,NO);
        }    
        else if (params->srcElementIndex == 0) { 
            //Enable element indexing mode for dst
            handle->config.idx = EDMA_FMK(IDX,ELEIDX,
                (params->dstElementIndex));
            handle->config.opt |= 
                EDMA_FMKS(OPT,FS,NO)   |            
                EDMA_FMKS(OPT,SUM,INC) | 
                EDMA_FMKS(OPT,DUM,IDX) |
                EDMA_FMKS(OPT,2DS,NO) |
                EDMA_FMKS(OPT,2DD,NO);
        }
        else if (params->dstElementIndex == 0) { 
            //Enable element indexing mode for src 
            handle->config.idx = EDMA_FMK(IDX,ELEIDX,
                (params->srcElementIndex));
            handle->config.opt |= 
                EDMA_FMKS(OPT,FS,NO)   |            
                EDMA_FMKS(OPT,SUM,IDX) | 
                EDMA_FMKS(OPT,DUM,INC) |
                EDMA_FMKS(OPT,2DS,NO) |
                EDMA_FMKS(OPT,2DD,NO);
        }  
        else if (params->dstElementIndex == params->srcElementIndex) {
            //Enable element indexing mode for src and dst
            handle->config.idx = EDMA_FMK(IDX,ELEIDX,
                (params->srcElementIndex));
            handle->config.opt |= 
                EDMA_FMKS(OPT,FS,NO)   |            
                EDMA_FMKS(OPT,SUM,IDX) | 
                EDMA_FMKS(OPT,DUM,IDX) |
                EDMA_FMKS(OPT,2DS,NO) |
                EDMA_FMKS(OPT,2DD,NO);
        }                
        else {          
            SYS_abort("Invalid combination of src and dst element indices");
        }
        
    }       
     
    //Set the element size field       
    switch (params->elemSize) {
        case IDMA2_ELEM8:
            (handle->config).opt |= EDMA_FMKS(OPT,ESIZE,8BIT);
            break;
        case IDMA2_ELEM16:
            (handle->config).opt |= EDMA_FMKS(OPT,ESIZE,16BIT);
            break;
        default:
            break;
    }
    
}



