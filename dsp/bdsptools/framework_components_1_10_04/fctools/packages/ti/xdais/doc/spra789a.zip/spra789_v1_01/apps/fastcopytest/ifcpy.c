/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== ifcpy.c ========
 *  Default creation parameters for all implementations of the FCPY
 *  module abstract interface. 
 *
 *  These parameters are included by the client of the fcpy algorithm(s), 
 *  and referenced by the algorithms.
 */
#include <std.h>

#include <ifcpy.h>

/*
 *  ======== IFCPY_PARAMS ========
 *  This static initialization defines the default parameters used to
 *  create an instance of a FCPY object.
 */
const IFCPY_Params IFCPY_PARAMS = {
    sizeof(IFCPY_PARAMS),    /* Size of this structure */
    8,                       /* Source Frame length */
    8,                       /* Number of frames for source */
    0,                       /* Stride between frames for source */
    8,                       /* Destination Frame length */
    8,                       /* Number of frames for destination */
    0                        /* Stride between frames for destination */
};



