/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_complete.c ========
 */
/*
 * ======== ACPY2_complete ======== 
 * Check to see if the data transfers have completed
 */
 
#pragma CODE_SECTION(ACPY2_complete, ".text:ACPY2_complete")

#include <std.h>

#include <csl_edma.h>

#include <_acpy2.h>
#include <idma2_priv.h>


Int ACPY2_complete(IDMA2_Handle handle)
{       
    Uint32 mask = 1 << (handle->lastTCC);
        
    /*
     * If the entry in the table corresponding to the last TCC
     *     used by this handle matches the handle itself, then we need 
     *     to check the TCC bit to verify transfer completion.
     *     Otherwise, the TCC has already been assigned to a subsequent
     *     transfer, meaning the last transfer on this handle has already
     *     completed.
     */
    if ((_ACPY2_TCCTable[handle->lastTCC] == handle) && 
        !(EDMA_RGET(CIPR) & mask) ) {
        return (0);  //Not complete
    }
    else {
        return (1);  //complete
    }
}



