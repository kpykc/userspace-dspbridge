/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== _acpy2.h ========
 *
 */

#ifndef _ACPY2_
#define _ACPY2_

#include <acpy2.h>
#include <idma2.h>

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

/*
 *  The maximum number of TCCs supported in this ACPY implementation.
 *  This number is set so that C6211/C6711 and C64x devices can all 
 *  share this implementation. Note that on C64x devices, only 16
 *  of all available TCCs are supported since we only use the lower
 *  half of the lower CIPR register.
 */
#define _ACPY2_TCCTABLESIZE 16 

//Table recording which handle last used a particular TCC
extern IDMA2_Handle _ACPY2_TCCTable[];           
    
extern Int _ACPY2_TCCmask;  //Bits in CIPR reserved for ACPY2's use
extern Char _ACPY2_TCCsAllocated[];  //List of TCCs allocated for ACPY2

#ifdef __cplusplus
}
#endif /*__cplusplus*/

#endif /* _ACPY2_ */



