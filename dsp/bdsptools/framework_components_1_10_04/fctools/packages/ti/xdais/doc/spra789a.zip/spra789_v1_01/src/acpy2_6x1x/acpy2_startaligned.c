/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_startAligned.c ========
 *  C model of the assembly code in acpy2_startAligned.s62
 */
 
#include <std.h>

#include <hwi.h>

#include <csl_edma.h>

#include <idma2_priv.h>
#include <_acpy2.h>

#pragma CODE_SECTION(ACPY2_startAligned, ".text:ACPY2_startAligned")

Void ACPY2_startAligned(IDMA2_Handle handle, Void * src, Void *dst, Uns cnt) 
{
    Int csr;
    Int temp;                   //variable used to check available TCCs
    Int usedTCC;                //actual TCC chosen for present transfer
    Uns * base = (Uns *)_EDMA_QOPT_ADDR;  //base address of QDMA regs
    
    //Disable interrupts when modifying QDMA registers
    csr = HWI_disable();
    
    //Determines if there are TCCs available for ACPY2's use
    temp = EDMA_RGET(CIPR) & _ACPY2_TCCmask;
    base[_EDMA_QSRC_OFFSET]  = (Uns)src;
    base[_EDMA_QDST_OFFSET]  = (Uns)dst;
    
    while(temp == 0)
    {   
        HWI_restore(csr);
        csr = HWI_disable();
        temp = EDMA_RGET(CIPR) & _ACPY2_TCCmask;
        base[_EDMA_QSRC_OFFSET]  = (Uns)src;
        base[_EDMA_QDST_OFFSET]  = (Uns)dst;
    }
                
    //Calculate the TCC number used
    usedTCC = 31 - _lmbd(1, temp);              

    //Clear TCC bit in CIPR to record next transfer completion event
    EDMA_RSET(CIPR,1 << usedTCC);                                       

    //Record in TCC table as the last handle to have used this TCC 
    _ACPY2_TCCTable[usedTCC] = handle; 
    
    //Record this TCC as the last TCC used by this handle
    handle->lastTCC = usedTCC;
        
    //Write to QDMA registers. 
    base[_EDMA_QIDX_OFFSET] = (handle->config).idx;
    base[_EDMA_QOPT_OFFSET] = (handle->config).opt | (usedTCC << 16);  
    if(handle->params.xType != IDMA2_1D1D)
    {   
        base[_EDMA_QSCNT_OFFSET] = (handle->config).cnt + cnt;
    }
    else
    {   
        base[_EDMA_QSCNT_OFFSET]  = (Uns)cnt;
    }

    HWI_restore(csr); //reenable interrupts

}

