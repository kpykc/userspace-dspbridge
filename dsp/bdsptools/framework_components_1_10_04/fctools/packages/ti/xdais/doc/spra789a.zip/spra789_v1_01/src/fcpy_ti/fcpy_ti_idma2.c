/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== fcpy_ti_idma2.c ========
 *  FCPY Module - TI implementation of a FCPY algorithm
 *
 *  This file contains an implementation of the IDMA2 interface
 */

#pragma CODE_SECTION(FCPY_TI_dmaChangeChannels, ".text:dmaChangeChannels")
#pragma CODE_SECTION(FCPY_TI_dmaGetChannelCnt, ".text:dmaGetChannelCnt")
#pragma CODE_SECTION(FCPY_TI_dmaGetChannels, ".text:dmaGetChannels")
#pragma CODE_SECTION(FCPY_TI_dmaInit, ".text:dmaInit")

#include <std.h>

#include <fcpy_ti_priv.h>
#include <ialg.h>
#include <idma2.h>

#define CHANNEL0 0
#define CHANNEL1 1
#define CHANNEL2 2

#define NUM_LOGICAL_CH 3

/*
 *  ======== FCPY_TI_dmaChangeChannels ========
 *  Update instance object with new logical channel.
 */
Void FCPY_TI_dmaChangeChannels(IALG_Handle handle, IDMA2_ChannelRec dmaTab[])
{
    FCPY_TI_Obj *fcpy = (Void *)handle;

    fcpy->dmaHandle1D1D8B = dmaTab[CHANNEL0].handle;
    fcpy->dmaHandle1D2D8B = dmaTab[CHANNEL1].handle;
    fcpy->dmaHandle2D1D8B = dmaTab[CHANNEL2].handle;

}

/*
 *  ======== FCPY_TI_dmaGetChannelCnt ========
 *  Return max number of logical channels requested.
 */
Int FCPY_TI_dmaGetChannelCnt(Void)
{
    return(NUM_LOGICAL_CH);
}

/*
 *  ======== FCPY_TI_dmaGetChannels ========
 *  Declare DMA resource requirement/holdings. 
 */
Int FCPY_TI_dmaGetChannels(IALG_Handle handle, IDMA2_ChannelRec dmaTab[])
{
    FCPY_TI_Obj *fcpy = (Void *)handle;

    /* Initial values on logical channels */
    dmaTab[CHANNEL0].handle = fcpy->dmaHandle1D1D8B; 
    dmaTab[CHANNEL1].handle = fcpy->dmaHandle1D2D8B; 
    dmaTab[CHANNEL2].handle = fcpy->dmaHandle2D1D8B; 

    /* Want all transfers to be serialized (to simplify debugging) */
    dmaTab[CHANNEL0].queueId = 0; 
    dmaTab[CHANNEL1].queueId = 0; 
    dmaTab[CHANNEL2].queueId = 0; 
    
    return (NUM_LOGICAL_CH);
}

/*
 *  ======== FCPY_TI_dmaInit========
 *  Initialize instance object with granted logical channel.
 */
Int FCPY_TI_dmaInit(IALG_Handle handle, IDMA2_ChannelRec dmaTab[])
{
    FCPY_TI_Obj *fcpy = (Void *)handle;     

    fcpy->dmaHandle1D1D8B = dmaTab[CHANNEL0].handle;
    fcpy->dmaHandle1D2D8B = dmaTab[CHANNEL1].handle;
    fcpy->dmaHandle2D1D8B = dmaTab[CHANNEL2].handle;
    
    return (IALG_EOK);
}



