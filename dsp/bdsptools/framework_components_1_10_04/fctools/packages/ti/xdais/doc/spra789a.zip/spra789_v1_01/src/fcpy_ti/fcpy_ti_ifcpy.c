/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== fcpy_ti_ifcpy.c ========
 *  FCPY Module - TI implementation of a FCPY algorithm
 *
 *  This file contains the implementation of the IFCPY abstract interface. 
 */

#pragma CODE_SECTION(FCPY_TI_doCopy, ".text:doCopy")
#pragma CODE_SECTION(FCPY_TI_control, ".text:control")

#include <std.h>

#include <xdas.h>
#include <idma2.h>
#include <acpy2.h>

#include <ifcpy.h>
#include <fcpy_ti_priv.h>
#include <fcpy_ti.h>


/*
 *  ======== FCPY_TI_doCopy ========
 */
Void FCPY_TI_doCopy(IFCPY_Handle handle, Void * in, Void * out)
{
    FCPY_TI_Obj *fcpy = (Void *)handle;
    IDMA2_Params params;

    /* Configure the logical channel */ 
    params.xType = IDMA2_1D1D;
    params.elemSize = IDMA2_ELEM8;
    params.numFrames = 0;    // Not used in 1D1D transfer 
    params.srcFrameIndex = 0;       // Not used in 1D1D transfer 
    params.dstFrameIndex = 0;       // Not used in 1D1D transfer 
    params.srcElementIndex = 0;        
    params.dstElementIndex = 0;
    
    /* Configure logical dma channel */
    ACPY2_configure(fcpy->dmaHandle1D1D8B, &params);

    /* Configure the logical channel */
    params.xType = IDMA2_2D1D;
    params.elemSize = IDMA2_ELEM8;
    params.numFrames = fcpy->srcNumLines;        
    params.srcFrameIndex = fcpy->srcStride; 
    params.dstFrameIndex = 0;     
    
    /* Configure logical dma channel */
    ACPY2_configure(fcpy->dmaHandle2D1D8B, &params);

    /* Configure the logical channel */
    params.xType = IDMA2_1D2D;
    params.elemSize = IDMA2_ELEM8;
    params.numFrames = 0;     
    params.srcFrameIndex = 0;
    params.dstFrameIndex = 0;       

    /* Configure logical dma channel */
    ACPY2_configure(fcpy->dmaHandle1D2D8B, &params);
    
    /* Use DMA to fcpy input buffer into working buffer */
    ACPY2_start(fcpy->dmaHandle2D1D8B, (Void *)in, 
        (Void *)(fcpy->workBuf1),
        (Uns)(fcpy->srcLineLen));

    /* Check that dma transfer has completed before finishing "processing" */
    while (!ACPY2_complete(fcpy->dmaHandle2D1D8B)) {
        ;
    };

    /* Use the DMA to copy data from working buffer 1 to working buffer 2 */ 
    ACPY2_start(fcpy->dmaHandle1D1D8B, (Void *)(fcpy->workBuf1),
        (Void *)(fcpy->workBuf2), 
        (Uns)((fcpy->srcLineLen) * (fcpy->srcNumLines)));

    /* wait for transfer to finish  */              
    ACPY2_wait(fcpy->dmaHandle1D1D8B);

    /* Quickly configure NumFrames and FrameIndex values for dmaHandle1D2D8B */
    ACPY2_setNumFrames(fcpy->dmaHandle1D2D8B, fcpy->dstNumLines);
    ACPY2_setDstFrameIndex(fcpy->dmaHandle1D2D8B, fcpy->dstStride);

    /* Use the DMA to copy data from working buffer 2 to output buffer */ 
    ACPY2_start(fcpy->dmaHandle1D2D8B, (Void *)(fcpy->workBuf2),
        (Void *)out, (Uns)(fcpy->dstLineLen));
    
    /* wait for all transfers to complete before returning to the client */
    ACPY2_wait(fcpy->dmaHandle1D2D8B);

}

/*
 *  ======== FCPY_TI_control ========
 */
XDAS_Bool FCPY_TI_control(IFCPY_Handle handle, IFCPY_Cmd cmd, IFCPY_Status
                          *status)
{
    FCPY_TI_Obj *fcpy = (FCPY_TI_Obj *)handle;

    if (cmd == IFCPY_GETSTATUS) {
        status->srcLineLen = fcpy->srcLineLen;
        status->srcNumLines = fcpy->srcNumLines;
        status->srcStride = fcpy->srcStride;
        status->dstLineLen = fcpy->dstLineLen;
        status->dstNumLines = fcpy->dstNumLines;
        status->dstStride = fcpy->dstStride;
        return (XDAS_TRUE);
    }
    else if (cmd == IFCPY_SETSTATUS) {
        /* 
         * Note that srcLineLen and srcNumLines cannot be changed once the
         * algorithm has been instantiated, as they determine the sizes of
         * the internal buffers used in FCPY_TI
         */ 
        fcpy->srcStride = status->srcStride;
        fcpy->dstLineLen = status->dstLineLen;
        fcpy->dstNumLines = status->dstNumLines;
        fcpy->dstStride = status->dstStride;
        return (XDAS_TRUE);
    }    
    
    /* Should not happen */
    return (XDAS_FALSE);
}


