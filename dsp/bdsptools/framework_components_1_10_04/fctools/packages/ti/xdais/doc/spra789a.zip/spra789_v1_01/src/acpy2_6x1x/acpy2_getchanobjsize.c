/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_getchanobjsize.c ========
 */
#pragma CODE_SECTION(ACPY2_getChanObjSize, ".text:ACPY2_getChanObjSize")

#include <std.h>

#include <idma2_priv.h>
 
/*
 *  ======== ACPY2_getChanObjSize ======== 
 *  Get the size of the IDMA2 channel object.
 */

Uns ACPY2_getChanObjSize(Void)
{
    return (sizeof (IDMA2_Obj));
}


 
