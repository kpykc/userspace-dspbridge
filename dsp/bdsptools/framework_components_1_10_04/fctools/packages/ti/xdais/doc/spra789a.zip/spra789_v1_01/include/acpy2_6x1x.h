/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_6x1x.h ========
 *  This header defines the configuration structure used to configure 
 *  the ACPY2 library.
 *
 */
 
#ifndef ACPY2_6X1X_
#define ACPY2_6X1X_

#include <ialg.h>
#include <acpy2.h>

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

/*
 *  ======== ACPY2_6X1X_Config ========
 *  The module configuration structure for ACPY2.  It is set at design 
 *  time by the system integrator to adjust the behaviour of the module
 *  to be optimal for its execution environment.
 */
typedef struct ACPY2_6X1X_Config {
    Int numTCC;         // number of TCCs reserved for use in ACPY2. 
                        // It determines the number of simultaneous
                        // transfer requests that can be submitted 
                        // by ACPY2_start/ACPY2_startAligned.  It
                        // should be set to a number that does not
                        // exceed the hardware queue length on the
                        // target.  Otherwise, CPU stalls could result.
} ACPY2_6X1X_Config;

/*
 *  ======== ACPY2_6X1X ========
 *  Default module configuration structure (defined in acpy2_6x1x.c)
 */
extern ACPY2_6X1X_Config ACPY2_6X1X;

/*
 * ======== ACPY2_6X1X_init ======== 
 * Initialize the ACPY2_6X1X module
 */
extern Void ACPY2_6X1X_init(Void);

/*
 * ======== ACPY2_6X1X_exit ======== 
 * Finalization function of the ACPY2_6X1X module
 */
extern Void ACPY2_6X1X_exit(Void);

#ifdef __cplusplus
}
#endif /*__cplusplus*/

#endif  /* ACPY2_6X1X_ */


