/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_6x1x_init.c ========
 */

#pragma CODE_SECTION(ACPY2_6X1X_init, ".text:ACPY2_6X1X_init");

#include <std.h> 
 
#include <acpy2.h>

/*
 * ======== ACPY2_6X1X_init ======== 
 * Initialize the ACPY2 module
 */
Void ACPY2_6X1X_init(Void) 
{
    ACPY2_init();
}



