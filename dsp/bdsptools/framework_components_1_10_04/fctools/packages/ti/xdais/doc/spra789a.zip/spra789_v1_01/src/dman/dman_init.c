/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== dman_init.c ========
 *  Initialize the DMAN module
 */

#pragma CODE_SECTION(DMAN_init, ".text:init");

#include <std.h>

#include <dman.h>

/*
 *  ======== DMAN_init ======== 
 *  Initialize the DMAN module
 */
Void DMAN_init(Void) 
{
}


