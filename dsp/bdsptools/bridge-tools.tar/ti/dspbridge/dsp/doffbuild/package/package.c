#ifndef __config__
char __dummy__;
#define __xdc_PKGVERS null
#define __xdc_PKGNAME ti.dspbridge.dsp.doffbuild
#define __xdc_PKGPREFIX ti_dspbridge_dsp_doffbuild_
#ifdef __xdc_bld_pkg_c__
#include __xdc_bld_pkg_c__
#endif

#else
#include <string.h>

#ifndef xdc_rts_System__include
#ifndef __nested__
#define __nested__
#include <xdc/rts/System.h>
#undef __nested__
#else
#include <xdc/rts/System.h>
#endif
#endif

#ifndef xdc_rts_Memory__include
#ifndef __nested__
#define __nested__
#include <xdc/rts/Memory.h>
#undef __nested__
#else
#include <xdc/rts/Memory.h>
#endif
#endif

#ifndef xdc_rts_Error__include
#ifndef __nested__
#define __nested__
#include <xdc/rts/Error.h>
#undef __nested__
#else
#include <xdc/rts/Error.h>
#endif
#endif


#endif
